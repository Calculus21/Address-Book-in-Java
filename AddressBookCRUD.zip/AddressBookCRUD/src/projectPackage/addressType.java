package projectPackage;


public class addressType {
	
	private String streetAddress;
	private String City;
	private String state;
	private String ZipCode;
	
	/**
	 * Default addressType constructor
	 * @param strtAddresses
	 * @param cty
	 * @param statee
	 * @param zipCode
	 */
	public addressType(String strtAddresses, String cty, String statee, String zipCode) {
		
		this.streetAddress = strtAddresses;
		this.City = cty;
		this.state = statee;
		this.ZipCode = zipCode;
	}
	
	/**
	 * Returns array of street addresses.
	 * @return
	 */
	public String getStreetAddresses() {
		return streetAddress;
	}
	
	/**
	 * Returns city.
	 * @return
	 */
	public String getCity() {
		return City;
	}
	
	/**
	 * Returns State.
	 * @return
	 */
	public String getState() {
		return state;
	}
	
	/**
	 * Returns Zip code.
	 * @return
	 */
	public String getZipCode() {
		return ZipCode;
	}

	/**
	 * Sets street address array to passed array.
	 * @param addresses
	 */
	public void setStreetAddresses(String addresses) {
		this.streetAddress = addresses;
	}

	/**
	 * Sets City to passed value.
	 * @param city
	 */
	public void setCity(String city) {
		this.City = city;
	}
	
	/**
	 * Sets state to passed value.
	 * @param state
	 */
	public void setState(String state) {
		this.state = state;
	}
	
	/**
	 * Sets Zip Code to passed value.
	 * @param ZipCode
	 */
	public void setZipCode(String ZipCode) {
		this.ZipCode = ZipCode;
	}
	
	/**
	 * Prints full address to the console.
	 */
	public void printFullAddress() {
		System.out.println(this.streetAddress+ " "+ this.City + " "+ this.state+ " "+ this.ZipCode);
	}
	
	/**
	 * Returns full address as a string
	 * @return
	 */
	public String getFullAddress() {
		return this.streetAddress+ " "+ this.City + " "+ this.state+ " "+ this.ZipCode;
	}
	
}
