package projectPackage;

//Written by Jonathan Acevedo

/**
 * This class stores first and lastname string. Also provides functions to get and set variables.
 * @author Calculo
 *
 */
public class personType {
	
	private String firstName;
	private String lastName;
	
	/*
	 * Default personType constructor. Initializes first & last name.
	 */
	public personType() { 
	
		firstName = ""; 
		lastName = "";
	}
	
	/**
	 * Constructor with parameters. First and last name.
	 * @param f
	 * @param l
	 */
	public personType(String f, String l) { 
		
		firstName = f; 
		lastName = l;
	}
	
	/**
	 * Prints first and last name as a string on the console. 
	 */
	public void printName() {
		System.out.print(firstName + " "+ lastName);
	}
	
	/**
	 * Sets the first and last name to passed string parameters.
	 * @param f
	 * @param l
	 */
	public void setName(String f, String l) { 
		
		firstName = f; 
		lastName = l;
	}
	
	/**
	 * Sets the first name to passed string parameters.
	 * @param f
	 */
	public void setFirstName(String f) { 
		
		firstName = f; 
	}
	
	/**
	 * Sets the last name to passed string parameters.
	 * @param l
	 */
	public void setLastName(String l) {
		lastName = l;
	}
	
	/**
	 * returns first name as a string.
	 * @return
	 */
	public String getFirstName() {
		return firstName;
	}
	
	/**
	 * returns last name as a string.
	 * @return
	 */
	public String getLastName() {
		return lastName;
	}

}
