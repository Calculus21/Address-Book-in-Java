package projectPackage;
import java.util.*;

//This Class executes the Address Book Program.

public class mainClass {

	public static void main(String[] args) {
		//boolean run = true;
		
		Scanner Input = new Scanner(System.in);
		//Testing the personType class with the mainMenu function to print a first and lastname.
		personType Jonathan = new personType("Jonathan", "Acevedo");
		mainMenu(Jonathan, Input);
		

	}
	
	/**
	 * Prints menu and validates input.
	 * @param person
	 * @param input
	 */
	private static void mainMenu(personType person, Scanner input) {
		
		
		System.out.println("********************************************************************");
		System.out.println("*                                                                  *");
		System.out.println("*          "+person.getFirstName() + " " + person.getLastName()+"'s Address Book in Java.                *");
		System.out.println("*                                                                  *");
		System.out.println("*                                                                  *");
		System.out.println("*                                                                  *");
		System.out.println("*    (1) Add Contact.              (5) Load Address Book           *");
		System.out.println("*    (2) Modify Contact            (6) Search Address Book         *");
		System.out.println("*    (3) Delete contact            (7) Exit Application            *");
		System.out.println("*    (4) View Address Book                                         *");
		System.out.println("*                                                                  *");
		System.out.println("*                                                                  *");
		System.out.println("*                                                                  *");
		System.out.println("********************************************************************");
		
		System.out.print  ("                     What do you want to do? ");
		menuControls(OptionMenuInput(input));
		
	}

	/**
	 * This function accepts an option controls program flow based on it.
	 * @param option
	 */
	private static void menuControls(int option) {
		
		System.out.println("\n\n                 Entered menu control. Option: " + option);
		
	}
	
	/**
	 * Accepts and validates user input.
	 * @param Input
	 * @return option
	 */
	private static int OptionMenuInput(Scanner Input) {
		int option = 0;
		while (option < 1 || option > 7) 
		{
			if(Input.hasNextInt()) {
				
			option = Input.nextInt();
			if (option < 1 || option > 7) {
				System.out.print("Please select an option between 1 and 7: ");
				}
			}
			else {
				System.out.print("Please select a numeric option: ");
		        Input.next(); // -->important THIS CLEARS SCANNER
		        //System.out.println();
			}
		} 
		return option;
	}

	
}




/**
 * 
 * To validate name input
 * while(!name.matches("[a-zA-Z ,]+"))
 * {System.out.print("Please enter a correct name.");
 * name = input.nextLine();
 */


//while(run) {
//System.out.println("***********************************************************************");
//System.out.println("**                                                                   **");
//System.out.println("**                                                                   **");
//System.out.println("**      ######    #####      #       ######    #   #                 **");
//System.out.println("**      #         #   #      #       #         #   #                 **");
//System.out.println("**      #         #   #      #       #         #   #                 **");
//System.out.println("**      #         #   ##     #       #         #   #                 **");
//System.out.println("**      ######     ###  ##   ####    ######    #####                 **");
//System.out.println("**                                                                   **");
//System.out.println("**                                                                   **");
//System.out.println("************************************************************************");
//
//
//System.out.println("Continue? ");
//int answer = Input.nextInt();
//if(answer == 1) {
//	run = false;
//}
//else {
//	continue;
//}
//}