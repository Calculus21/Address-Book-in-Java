package projectPackage;

public class dateType {
	private String monthName;
	private int monthDays;
	private int month;
	private int day;
	private int year;
	
	public dateType(int m, int d, int y) {		
		
		//If month passed is between 1 and 12 (January - December), assign passed value to month.
		if(m <= 12 || m >= 1) {
			this.month = m;
		}
		else {
			this.month= 1;
			System.out.print("\n\tMonth parameter not in range. Setting month to "+ this.month +".");
			sleep(1000);
		}
		
		//If month has 31 days. (Note: 7 months have 31 days.)
		if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
			//If passed day is between 1 and 31, assign it to member variable day.
			if (d <= 31 || d >= 1) {
				this.day = d;
			}
			else {
				this.day= 1;
				System.out.print("\n\tDay parameter not in range. Setting day to "+ this.day +".");
				sleep(1000);
			}
			
		}
		//If month has 30 days
		else if (month == 4 || month == 6 || month == 9 || month == 11) {
			
		}
		else
		
		
		
		
		this.year = y;
	}

	/**
	 * Function used to pause program execution for a specified time.
	 * @param milisecs
	 */
	public static void sleep(int milisecs) {
		try {
			Thread.sleep(milisecs);
		}
		catch (Exception e) {
			System.out.println("Unknown error in sleep function.\nCalled from dateType.");
		}
	}

	private void setMonthName(int m) {
		switch (m) {
		case: 1
			this.monthName = 
		
		}
	}

}
